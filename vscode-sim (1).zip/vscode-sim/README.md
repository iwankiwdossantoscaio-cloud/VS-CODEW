# VS Code Simulator

Simulador web interativo do VS Code.

## Funcionalidades
- **Botões do Explorador**: Criar novos arquivos (`.py`, `.js`, `.c`, etc.) e novas pastas.
- **Renomear Arquivos/Pastas**: Duplo clique no item ou clique no ícone de lápis para alterar o nome.
- **Painel de Execução**: Botão "Executar" reposicionado perfeitamente na barra superior.
- **Terminal Interativo**: Execução e exibição de saídas para scripts Python, JS e C.

## Como Executar
1. Certifique-se de ter o Node.js instalado.
2. Execute `node server.js` no terminal.
3. Abra o navegador em `http://localhost:3000`.
